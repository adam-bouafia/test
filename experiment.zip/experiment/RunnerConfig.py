import os
import subprocess
import psutil
import time
import json
from transformers import AutoModelForCausalLM, AutoTokenizer
from EventManager.Models.RunnerEvents import RunnerEvents
from EventManager.EventSubscriptionController import EventSubscriptionController
from ConfigValidator.Config.Models.RunTableModel import RunTableModel
from ConfigValidator.Config.Models.FactorModel import FactorModel
from ConfigValidator.Config.Models.RunnerContext import RunnerContext
from ConfigValidator.Config.Models.OperationType import OperationType
from ExtendedTyping.Typing import SupportsStr
from ProgressManager.Output.OutputProcedure import OutputProcedure as output
from typing import Dict, Optional
from pathlib import Path

# Dictionary to store model configurations
model_configs = {
    "mistral-v0.1": {
        "model_name": "mistralai/Mistral-7B-Instruct-v0.1",
        "tokenizer_name": "mistralai/Mistral-7B-Instruct-v0.1",
    }
}

class RunnerConfig:
    ROOT_DIR = Path("../data/")
    name: str = "test_runner_experiment"
    results_output_path: Path = ROOT_DIR / 'experiments'
    operation_type: OperationType = OperationType.AUTO
    time_between_runs_in_ms: int = 1000 * 60  # 1 minute between runs (can be minimized for a quick test)
    
    def __init__(self):
        EventSubscriptionController.subscribe_to_multiple_events([
            (RunnerEvents.BEFORE_EXPERIMENT, self.before_experiment),
            (RunnerEvents.BEFORE_RUN, self.before_run),
            (RunnerEvents.START_RUN, self.start_run),
            (RunnerEvents.START_MEASUREMENT, self.start_measurement),
            (RunnerEvents.INTERACT, self.interact),
            (RunnerEvents.STOP_MEASUREMENT, self.stop_measurement),
            (RunnerEvents.STOP_RUN, self.stop_run),
            (RunnerEvents.POPULATE_RUN_DATA, self.populate_run_data),
            (RunnerEvents.AFTER_EXPERIMENT, self.after_experiment)
        ])
        self.run_table_model = None
        output.console_log("Custom config loaded")

    def before_experiment(self) -> None:
        print("Installing dependencies...")
        subprocess.check_call(["pip", "install", "-r", "requirements.txt"])
        self.experiment_start_time = time.time()  # Track total experiment start time
        output.console_log("Experiment started.")
        output.console_log("Config.before_experiment() called!")

    # Modify to only use Mistral v0.1 with a single task and short input
    def create_run_table_model(self) -> RunTableModel:
        main_factor = FactorModel("model_version", ['v0.1'])  # Test only Mistral v0.1
        blocking_factor_1 = FactorModel("candidate_family", ['mistral'])  # Only Mistral family
        blocking_factor_2 = FactorModel("task_type", ['generation'])  # Only text generation
        co_factor = FactorModel("input_size", ['short'])  # Use short input for faster test

        self.run_table_model = RunTableModel(
            factors=[main_factor, blocking_factor_1, blocking_factor_2, co_factor],
            exclude_variations=[],  # No exclusions, just one configuration
            repetitions=1,  # Run just once for a quick test
            data_columns=['cpu_utilization', 'ram_usage', 
                          'gpu_utilization', 'vram_usage',
                          'performance_score', 'performance_score_type',
                          'response_time', 'input_token_size', 'output_token_size',
                          'energy_consumption']
        )
        return self.run_table_model

    def load_model(self, context: RunnerContext):
        # Get the run variation, such as "mistral-v0.1"
        run_variation = context.run_variation["model_version"] + "-" + context.run_variation["candidate_family"]

        # Fetch the model and tokenizer name from the dictionary
        if run_variation in model_configs:
            model_name = model_configs[run_variation]["model_name"]
            tokenizer_name = model_configs[run_variation]["tokenizer_name"]
            print(f"Loading model: {model_name}, tokenizer: {tokenizer_name}")
            model = AutoModelForCausalLM.from_pretrained(model_name)
            tokenizer = AutoTokenizer.from_pretrained(tokenizer_name)
            return model, tokenizer
        else:
            raise ValueError(f"Model configuration not found for run variation: {run_variation}")

    def before_run(self) -> None:
        output.console_log("Config.before_run() called!")

    def start_run(self, context: RunnerContext) -> None:
        self.run_start_time = time.time()  # Track the start time for each individual run
        output.console_log("Config.start_run() called!")

    def start_measurement(self, context: RunnerContext) -> None:
        output.console_log("Config.start_measurement() called!")
        context.run_data['gpu_utilization'] = subprocess.getoutput("nvidia-smi --query-gpu=utilization.gpu --format=csv,noheader,nounits")
        context.run_data['vram_usage'] = subprocess.getoutput("nvidia-smi --query-gpu=memory.used --format=csv,noheader,nounits")

    def interact(self, context: RunnerContext) -> None:
        output.console_log("Config.interact() called!")
        input_text = self.get_task_prompt(context)
        model, tokenizer = self.load_model(context)
        
        inputs = tokenizer(input_text, return_tensors="pt")
        start_time = time.time()
        outputs = model.generate(**inputs)
        end_time = time.time()
        
        context.run_data["response_time"] = end_time - start_time
        context.run_data["output_text"] = tokenizer.decode(outputs[0], skip_special_tokens=True)

    def stop_measurement(self, context: RunnerContext) -> None:
        output.console_log("Config.stop_measurement called!")

    def stop_run(self, context: RunnerContext) -> None:
        run_end_time = time.time()
        total_run_time = run_end_time - self.run_start_time
        output.console_log(f"Run completed in {total_run_time:.2f} seconds.")
        output.console_log("Config.stop_run() called!")

    def populate_run_data(self, context: RunnerContext) -> Optional[Dict[str, SupportsStr]]:
        cpu_usage = psutil.cpu_percent()
        ram_usage = psutil.virtual_memory().percent
        return {
            "cpu_utilization": cpu_usage,
            "ram_usage": ram_usage,
            "gpu_utilization": context.run_data.get('gpu_utilization'),
            "vram_usage": context.run_data.get('vram_usage'),
            "response_time": context.run_data.get('response_time'),
            "performance_score": "N/A",
            "energy_consumption": "N/A"
        }

    def after_experiment(self) -> None:
        experiment_end_time = time.time()
        total_experiment_duration = experiment_end_time - self.experiment_start_time
        hours, remainder = divmod(total_experiment_duration, 3600)
        minutes, _ = divmod(remainder, 60)
        output.console_log(f"Total experiment duration: {int(hours)} hours and {int(minutes)} minutes.")
        output.console_log("Config.after_experiment() called!")

    def get_task_prompt(self, context: RunnerContext):
        task_type = context.run_table_model["task_type"]
        input_size = context.run_table_model["input_size"]
        if task_type == "generation":
            return "Generate a quick sentence."  # Simplified prompt for fast test

if __name__ == "__main__":
    config = RunnerConfig()
    config.create_run_table_model()
